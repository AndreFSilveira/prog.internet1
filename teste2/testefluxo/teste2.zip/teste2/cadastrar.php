<?php
    $valor=$_GET['dado'];

   session_start();
    if(!isset($_SESSION['usuario'])){

        header("location: login.php");
    }

    $database="mydb";
    $conexao=mysql_connect('Localhost','root','12345') or die (mysql_error());
    $banco=mysql_select_db($database)or die(mysql_error());
    
    $sql=("SELECT * FROM Marcas");
    $marca=mysql_query($sql);
    $sql=("SELECT * FROM Tipo_Veiculo");
    $tipo=mysql_query($sql);

?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Cadastro</title>
        <link href="css/ui-lightness/jquery-ui-1.9.2.custom.css" rel="stylesheet">
        <script src="js/jquery-1.8.3.js"></script>
        <script src="js/jquery-ui-1.9.2.custom.js"></script>
        <link rel="stylesheet" type="text/css" href="moldes.css">
        <script>
          $(function() {
        
              $( "#accordion" ).accordion();
        
          });
        </script>
    </head>
    
    <body>


        <div id="cabecalho">
        <?php
            $secao_usuario  = $_SESSION['usuario'];
    
         echo "<b>Bem vindo</b>:  $secao_usuario "; ?>
         <div id="sair"><a href="?Sair">Sair</a></div>
        <?php if(isset($_REQUEST['Sair'])){
            session_destroy();
            header("location: login.php");
        }
        ?>
        </div>
        <div id="pagina">
        <div id="accordion">
        <h3>Cadastrar novo</h3>
            <ul>
                <li><a href="cadastrar.php?dado=1" name="cadastro_marca">Nova Marca</a></li>
                <li><a href="cadastrar.php?dado=2" name="cadastro_tipo">Novo Tipo</a></li>
                <li><a href="cadastrar.php?dado=3" name="cadastro_veiculo">Veiculos</a></li>
            </ul>
        <h3>Listar</h3>
            <ul>
                <li><a href="listar.php?id=1" name="listar_tipo">Tipos</a></li>
                <li><a href="listar.php?id=2" name="listar_marcas">Marcas</a></li>
                <li><a href="listar.php?id=3" name="listar_veiculos">Veiculos</a></li>
            </ul>
        <h3>Administrativo</h3>
            <ul>
                <li><a href="admin.php?ad=1" name="admin_marca">Listar Usuaios</a></li>
                <li><a href="admin.php?ad=2" name="admin_veiculo">Cadastrar Novo Usuario</a></li>
            </ul>
        <h3>Sair</h3>
            <ul>
                <li><a href="?Sair">Sair</a></li>
            </ul> 
            </div>   
        
            <?php 
                if($valor==1)
                {
            ?>

        <div class="cadastro">
            <form action="#" method="POST" name="Cadastrar_marca">
                <fieldset>
                    <label><h3>Cadastrar Marca</h3></label>
                    <br><label>Nome Marca: <input type="text" maxlength="45" name="Nome_Marca" ></label>
                    <br><label>Observaçoes:<br><textarea cols="40" rows="6" name="Obs_marca"></textarea></label>
                    <br><input class="botao1" type="submit" name="enviar" value="Cadastrar">
                    <input class="botao2" type="reset" value="Limpar Campos">
                </fieldset>
            </form>
        </div>
        </div>
        
        <?php
          }
          if($valor==2)
          {
        ?>

        <div class="cadastro">
            <form action="#" method="POST" name="cadastrar_tipo">
                <fieldset>
                    <label><h3>Cadastrar Tipo</h3></label>
                    <br><label>Tipo:<input type="text" maxlength="45" name="nome_tipo"></label>
                    <br><label>Observaçoes:<br><textarea cols="40" rows="6" name="Obs_name"></textarea></label>
                    <br><input class="botao1" type="submit" name="enviar" value="Cadastrar">
                    <input class="botao2" type="reset" value="Limpar Campos">
                </fieldset>
            </form>
        </div>
        <?
            }
            if($valor==3) 
            {
        ?>
        <div class="cadastro">
            <form action="#" name="cadastrar_veiculo" method="POST">
                <fieldset>
                    <label><h3>Cadastrar veiculo</h3></label>
                    <br><label>Placa:    <input type="text" name="Placa"></label>
                    <br><label>Ano:     <input type="number" name="Ano"></label>
                    <br><label>Modelo:<input type="text" name="Modelo"></label>
                    <br>Marcas:  <select name="marca">
                    <option selected>Selecione...</option>
                    <?

                        while($opmarca=mysql_fetch_assoc($marca)){
                         
                         echo"<option value=".$opmarca['IdMarcas'] . ">" . $opmarca['Marca'] . "</option>";
                        
                        }
                    ?>
                        </select>
                    <br><label>Tipo:     </label><select id="tipo">
                        <option selected>Selecione...</option>
                        
                        <?php

                            while($opitem=mysql_fetch_assoc($tipo)){
                                
                                echo"<option value=".$opitem['IdTipo_automoveis'] . ">" . $opitem['Tipo_Veiculo'] ."</option>";                            
                            }
                        ?>
                    
                    </select>    
                    <br><label>Observações:<br><textarea cols="40" rows="6" name="obs_veiculo"></textarea></label>
                    <br><input class="botao1" type="submit" value="Cadastrar" name="enviar">
                    <input class="botao2" type="reset" value="Limpar Campos">
                    <?
                        }
                    ?>
                </fieldset>
            </form>
        </div>
        </div>
    </body>
</html>