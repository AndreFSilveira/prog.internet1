<html>
    <head>
        <title>Cadastrar Novo</title>
    </head>
    <body>
        <h2>Informe <b>Todos</b> Os Campos Abaixo Para Cadastrar Um Novo Veiculo</h2>
        <form>
            <fieldset>
                <?php
                    class Cadastro_marca
                    {
                        var $codigo_marca;
                        var $marca;
                        var $obs_marca;

                        function novomarca ()
                        {

                        }
                    }
                ?>
            </fieldset>
        </form>
    </body>
</html>