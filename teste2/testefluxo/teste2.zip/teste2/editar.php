<?php
    /*paga a coneção com o banco
        session_start();

     if(!isset($_SESSION['email'])&&(!isset($_SESSION['senha']))){

        header("location: login.php");
    }
    ####verifica se esta aberta e continua logada caso contrario redireciona para o login#####
    */
    $i=0;
    ?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Pagina de  Edição</title>

        <link href="css/ui-lightness/jquery-ui-1.9.2.custom.css" rel="stylesheet">
        <script src="js/jquery-1.8.3.js"></script>
        <script src="js/jquery-ui-1.9.2.custom.js"></script>
        <style type="text/css">

    </head>
    <body>
        <?php
            if ($i==0){
        ?>

        <?php
            }
        ?>
    </body>
</html>