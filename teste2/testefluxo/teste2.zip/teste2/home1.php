<?php  
session_start();    
    if(!isset($_SESSION['usuario'])){

        header("location: login.php");
    }

    $dado=0;
?>
<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Pagina do Administrador</title>

        <link href="css/ui-lightness/jquery-ui-1.9.2.custom.css" rel="stylesheet">
        <script src="js/jquery-1.8.3.js"></script>
        <script src="js/jquery-ui-1.9.2.custom.js"></script>
        <link rel="stylesheet" type="text/css" href="moldes.css">
            
       <script>
          $(function() {
        
              $( "#accordion" ).accordion();
        
          });
       </script>
 <body>
    <div id="cabecalho">
        <?php
            $secao_usuario	= $_SESSION['usuario'];
    
         echo "<b>Bem vindo</b>:  $secao_usuario "; ?>
        <div id="sair"><a href="?Sair">Sair</a></div>
        <?php if(isset($_REQUEST['Sair'])){
            session_destroy();
            header("location: login.php");
        }
        ?>
    </div>
    <div id="pagina">

    <div id="accordion">
       <h3>Cadastrar novo</h3>
            <ul>
                <li><a href="cadastrar.php?dado=1" name="cadastro_marca">Nova Marca</a></li>
                <li><a href="cadastrar.php?dado=2" name="cadastro_tipo">Novo Tipo</a></li>
                <li><a href="cadastrar.php?dado=3" name="cadastro_veiculo">Veiculos</a></li>
            </ul>
        <h3>Listar</h3>
            <ul>
                <li><a href="listar.php?id=1" name="listar_tipo">Tipos</a></li>
                <li><a href="listar.php?id=2" name="listar_marcas">Marcas</a></li>
                <li><a href="listar.php?id=3" name="listar_veiculos">Veiculos</a></li>
            </ul>
        <h3>Administrativo</h3>
            <ul>
                <li><a href="admin.php?ad=1" name="admin_marca">Listar Usuaios</a></li>
                <li><a href="admin.php?ad=2" name="admin_veiculo">Cadastrar Novo Usuario</a></li>
            </ul>
        <h3>Sair</h3>
            <ul>
                <li><a href="?Sair">Sair</a></li>
            </ul>
    </div>
    </div>
    </body>
</html>
