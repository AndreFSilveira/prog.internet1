<?php

    $num=$_GET['id'];

    session_start();
    if(!isset($_SESSION['usuario'])){
            header("location: login.php");
    }
        
    $servidor ='localhost';
    $usuario  ='root';
    $senha    ='12345';
    $banco    ='mydb';

    $link   = mysql_connect($servidor,$usuario,$senha)or die ('Não foi possivel se conectar ao banco:'.mysql_error());
    $select = mysql_select_db($banco);
    $selecao="";

    
    $sql=("SELECT * FROM Tipo_Veiculo");
    $dadostipo=mysql_query($sql);
    $sql=("SELECT * FROM Marcas");
    $dadosmarca=mysql_query($sql);
    $sql=("SELECT * FROM Descricao_veiculo");
    $dadosveiculo=mysql_query($sql);
?>

<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8">
        <title>Cadastro</title>
        <link href="css/ui-lightness/jquery-ui-1.9.2.custom.css" rel="stylesheet">
        <script src="js/jquery-1.8.3.js"></script>
        <script src="js/jquery-ui-1.9.2.custom.js"></script>
        <link rel="stylesheet" type="text/css" href="moldes.css">
        <style type="text/css">
        
        </style>

        <script>
          $(function() {
        
              $( "#accordion" ).accordion();
        
          });
        </script>
    </head>
    
    <body>


        <div id="cabecalho">
        <?php
            $secao_usuario  = $_SESSION['usuario'];
    
         echo "<b>Bem vindo</b>:  $secao_usuario "; ?>
         <div id="sair"><a href="?Sair">Sair</a></div>
        <?php if(isset($_REQUEST['Sair'])){
            session_destroy();
            header("location: login.php");
        }
        ?>
        </div>
        <div id="pagina">
        <div id="accordion">
        <h3>Cadastrar novo</h3>
            <ul>
                <li><a href="cadastrar.php?dado=1" name="cadastro_marca">Nova Marca</a></li>
                <li><a href="cadastrar.php?dado=2" name="cadastro_tipo">Novo Tipo</a></li>
                <li><a href="cadastrar.php?dado=3" name="cadastro_veiculo">Veiculos</a></li>
            </ul>
        <h3>Listar</h3>
            <ul>
                <li><a href="listar.php?id=1" name="listar_tipo">Tipos</a></li>
                <li><a href="listar.php?id=2" name="listar_marcas">Marcas</a></li>
                <li><a href="listar.php?id=3" name="listar_veiculos">Veiculos</a></li>
            </ul>
        <h3>Administrativo</h3>
            <ul>
                <li><a href="admin.php?ad=1" name="admin_marca">Listar Usuaios</a></li>
                <li><a href="admin.php?ad=2" name="admin_veiculo">Cadastrar Novo Usuario</a></li>
            </ul>
        <h3>Sair</h3>
            <ul>
                <li><a href="?Sair">Sair</a></li>
            </ul> 
            </div>   
        
        <div calss="lista">
        <?php 
            if($num==1)
            {
        ?>    
        <table id="tipo">
            <tr>
                <td colspan="5" align="center"><b>Tabela de Tipos</b></td>
            </tr>
            <tr>
                <td align="center"><b>Codigo</b></td>
                <td align="center"><b>Tipo</b></td>
                <td align="center"><b>Obs Tipo</b></td>
                <td align="center"><b>Editar</b></td>
                <td align="center"><b>Excluir</b></td>
            </tr>
            <?
            While( $tbl =mysql_fetch_assoc($dadostipo))
            {
                $codigo    = $tbl["IdTipo_automoveis"];
                $tipo      = $tbl["Tipo_Veiculo"];
                $ob_tipo   = $tbl["Obs_Veiculo"];
                echo"<tr>";
                echo "<td>$codigo</td>";
                echo "<td>$tipo</td>";
                echo "<td>$ob_tipo</td>";
                echo "<td><a href='#'>editar</a></td>";
                echo "<td><a href='#'>excluir</a></td>";
                echo"</tr>";
            }
            ?>
            
        </table>
        <?php  
            }
        ?>
        <?php 
            if($num==2)
            {
        ?>    
        <table id="marcas">
            <tr>
                <td>Codigo</td>
                <td>Fabricante</td>
                <td>Obs Fabricante</td>
                <td>Editar</td>
                <td>Excluir</td>
            </tr>

            <?
            While( $tbl =mysql_fetch_assoc($dadosmarca))
            {
                $codigo    = $tbl["IdMarcas"];
                $marca     = $tbl["Marca"];
                $ob_marca  = $tbl["Obs_marcas"];
                
                echo "<tr>";
                echo "<td>$codigo</td>";
                echo "<td>$marca</td>";
                echo "<td>$ob_marca</td>";
                echo "<td><a href='#'>editar</a></td>";
                echo "<td><a href='#'>excluir</a></td>";
                echo"</tr>";
            }
            ?>
        </table>
        <?php  
            }
        ?>
        <?php 
            if($num==3)
            {
        ?>    
        <table id="veiculos">
            <tr>
                <td>Codigo:</td>
                <td>Tipo:</td>
                <td>Obs Tipo:</td>
                <td>Fabricante:</td>
                <td>Obs Fabricante:</td>
                <td>Ano:</td>
                <td>Placa:</td>
                <td>Modelo:</td>
                <td>Obs:</td>
                <td>Editar</td>
                <td>Excluir</td>
            </tr>

            <?/*
                $result= mysql_query($sql)
            While( $tbl =mysql_fetch_array($result))
            {
                $codigo    = $tbl["Id"];
                $tipo      = $tbl["Tipo"];
                $ob_tipo   = $tbl["Obs_Tipo"];
                $marca     = $tbl["Marca"];
                $ob_marca  = $tbl["Obs_Marca"];
                $ano       = $tbl["Ano"];
                $placa     = $tbl["Placa"];
                $modelo    = $tbl["Modelo"];
                $ob_veiculo= $tbl["Obs_Veiculo"];

                echo "<TR>";
                echo "<TD>$codigo<TD>";
            }*/
            ?>
        </table>
        <?php  
            }
        ?>

        </div>
    </body>
</html>