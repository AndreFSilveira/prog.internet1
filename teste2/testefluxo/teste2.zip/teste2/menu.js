
$(document).ready(function(){
    $(".conteudoMenu").hide();
    $(".itemMenu").click(function(){
        $(".conteudoMenu").slideUp("slow");
        $(this).next(".conteudoMenu").slideDown("slow");
    });
});